import 'package:flutter/material.dart';

/// Bottom nav global presente en TODAS las pantallas.
/// [activeIndex]: índice del ícono activo (rosado con punto indicador).
///   0 = gráfico, 1 = personas, 2 = carrito, 3 = caja herramientas (Producción)
/// Por defecto ninguno activo (-1).
class GlobalBottomNav extends StatelessWidget {
  final int activeIndex;
  const GlobalBottomNav({super.key, this.activeIndex = -1});

  static const _grey = Color(0xFFAAAAAA);
  static const _pink = Color(0xFFFF4FA3);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFEEEEEE), width: 1)),
      ),
      child: SafeArea(
        child: SizedBox(
          height: 64,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _Btn(icon: Icons.show_chart_rounded,     color: activeIndex == 0 ? _pink : _grey, isActive: activeIndex == 0, onTap: null),
              _Btn(icon: Icons.people_outline_rounded, color: activeIndex == 1 ? _pink : _grey, isActive: activeIndex == 1, onTap: null),
              _Btn(icon: Icons.shopping_cart_outlined, color: activeIndex == 2 ? _pink : _grey, isActive: activeIndex == 2, onTap: null),
              _Btn(
                icon: Icons.work_outline_rounded,
                color: activeIndex == 3 ? _pink : _grey,
                isActive: activeIndex == 3,
                onTap: () => _goToProduccion(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static void _goToProduccion(BuildContext context) {
    Navigator.of(context).pushNamedAndRemoveUntil(
      '/produccion',
      (route) => route.isFirst,
    );
  }
}

class _Btn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final bool isActive;
  final VoidCallback? onTap;
  const _Btn({required this.icon, required this.color, required this.isActive, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 72, height: 64,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 26, color: color),
            if (isActive)
              Container(
                margin: const EdgeInsets.only(top: 4),
                width: 5,
                height: 5,
                decoration: const BoxDecoration(
                  color: Color(0xFFFF4FA3),
                  shape: BoxShape.circle,
                ),
              )
            else
              const SizedBox(height: 9),
          ],
        ),
      ),
    );
  }
}
