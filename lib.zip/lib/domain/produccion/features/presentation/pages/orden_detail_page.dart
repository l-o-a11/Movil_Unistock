import 'package:flutter/material.dart';
import '../../../../../shared/widgets/global_bottom_nav.dart';
import 'package:provider/provider.dart';

import '../../../core/constants/app_colors.dart';
import '../../domain/entities/orden_entity.dart';
import '../../domain/entities/orden_detail_entity.dart';
import '../../domain/entities/ficha_costo_entity.dart';
import '../providers/orden_detail_provider.dart';
import '../widgets/detail/detail_app_bar.dart';
import '../widgets/detail/detail_status_views.dart';
import '../widgets/detail/progreso_card.dart';
import '../widgets/detail/etapas_card.dart';
import '../widgets/detail/produccion_terceros_card.dart';
import '../widgets/detail/referencias_card.dart';
import '../widgets/detail/historial_card.dart';

class OrdenDetailPage extends StatefulWidget {
  final OrdenEntity orden;
  const OrdenDetailPage({super.key, required this.orden});

  @override
  State<OrdenDetailPage> createState() => _OrdenDetailPageState();
}

class _OrdenDetailPageState extends State<OrdenDetailPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<OrdenDetailProvider>().loadDetail(widget.orden.id);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      bottomNavigationBar: const GlobalBottomNav(activeIndex: 3),
      appBar: DetailAppBar(ordenNumero: widget.orden.numero),
      body: Consumer<OrdenDetailProvider>(
        builder: (context, provider, _) {
          final state = provider.state;
          if (state.isLoading) return const DetailLoadingView();
          if (state.hasError) {
            return DetailErrorView(
              message: state.error ?? 'Error desconocido',
              onRetry: () => provider.loadDetail(widget.orden.id),
            );
          }
          if (!state.isLoaded || state.detail == null) return const SizedBox.shrink();
          return _DetailBody(detail: state.detail!);
        },
      ),
    );
  }
}

// ─── Body ─────────────────────────────────────────────────────────────────────

class _DetailBody extends StatefulWidget {
  final OrdenDetailEntity detail;
  const _DetailBody({required this.detail});

  @override
  State<_DetailBody> createState() => _DetailBodyState();
}

class _DetailBodyState extends State<_DetailBody>
    with SingleTickerProviderStateMixin {
  late final AnimationController _fadeAc = AnimationController(
    vsync: this, duration: const Duration(milliseconds: 480));
  late final Animation<double> _fadeAnim =
      CurvedAnimation(parent: _fadeAc, curve: Curves.easeOutCubic);

  bool _fichaExpanded = false;

  @override
  void initState() {
    super.initState();
    _fadeAc.forward();
  }

  @override
  void dispose() {
    _fadeAc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnim,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          ProgresoCard(detail: widget.detail),
          const SizedBox(height: 12),
          EtapasCard(detail: widget.detail),
          const SizedBox(height: 12),
          ProduccionTercerosCard(
            onTap: () {},
            ordenId: widget.detail.id,
            tipo: widget.detail.tipo,
          ),
          const SizedBox(height: 12),
          if (widget.detail.referencias.isNotEmpty) ...[
            ReferenciasCard(referencias: widget.detail.referencias),
            const SizedBox(height: 12),
          ],
          HistorialCard(historial: widget.detail.historial, onVerTodo: () {}),
          const SizedBox(height: 12),
          _FichaTecnicaExpandable(
            ficha: widget.detail.fichaCosto ??
                const FichaCostoEntity(
                  nombre: 'Sin ficha técnica asignada',
                  version: '—',
                  costoPorUnidad: 0,
                  costoTotal: 0,
                  completado: false,
                ),
            isExpanded: _fichaExpanded,
            onToggle: () => setState(() => _fichaExpanded = !_fichaExpanded),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
              icon: const Icon(Icons.home_rounded, size: 18),
              label: const Text('Volver al menú principal'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.textSecondary,
                side: const BorderSide(color: AppColors.cardBorder),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                textStyle: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Ficha Técnica Expandible ─────────────────────────────────────────────────

class _FichaTecnicaExpandable extends StatelessWidget {
  final FichaCostoEntity ficha;
  final bool isExpanded;
  final VoidCallback onToggle;

  const _FichaTecnicaExpandable({
    required this.ficha,
    required this.isExpanded,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withAlpha(10),
              blurRadius: 12,
              offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        children: [
          // Header tappable
          GestureDetector(
            onTap: onToggle,
            behavior: HitTestBehavior.opaque,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.description_rounded,
                        color: AppColors.primary, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Ficha técnica y costos',
                            style: TextStyle(
                                color: AppColors.textPrimary,
                                fontSize: 15,
                                fontWeight: FontWeight.w700)),
                        Text(
                          isExpanded ? 'Toca para cerrar' : 'Toca para ver detalle',
                          style: const TextStyle(
                              color: AppColors.textSecondary, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                  _StatusBadge(completado: ficha.completado),
                  const SizedBox(width: 8),
                  AnimatedRotation(
                    turns: isExpanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 250),
                    child: Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                          color: AppColors.chipBackground,
                          borderRadius: BorderRadius.circular(8)),
                      child: const Icon(Icons.keyboard_arrow_down_rounded,
                          size: 20, color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Contenido animado
          AnimatedSize(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOutCubic,
            child: isExpanded ? _FichaDetalle(ficha: ficha) : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

class _FichaDetalle extends StatelessWidget {
  final FichaCostoEntity ficha;
  const _FichaDetalle({required this.ficha});

  String _fmt(double v) {
    final s = v.toStringAsFixed(0);
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.divider))),
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Nombre y version
          Text(ficha.nombre,
              style: const TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(ficha.version,
              style: const TextStyle(
                  color: AppColors.textSecondary, fontSize: 12)),
          const SizedBox(height: 14),

          // Costos
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(12)),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Costo fijo por unidad',
                          style: TextStyle(
                              color: AppColors.textSecondary, fontSize: 11)),
                      const SizedBox(height: 4),
                      Text('\$${_fmt(ficha.costoPorUnidad)}',
                          style: const TextStyle(
                              color: AppColors.primary,
                              fontSize: 17,
                              fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
                Container(
                    width: 1,
                    height: 40,
                    color: AppColors.primary.withAlpha(40),
                    margin: const EdgeInsets.symmetric(horizontal: 12)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text('Costo total del pedido',
                          style: TextStyle(
                              color: AppColors.textSecondary, fontSize: 11),
                          textAlign: TextAlign.end),
                      const SizedBox(height: 4),
                      Text('\$${_fmt(ficha.costoTotal)}',
                          style: const TextStyle(
                              color: AppColors.primary,
                              fontSize: 17,
                              fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // Especificaciones
          _SectionTitle(title: 'Especificaciones técnicas'),
          const SizedBox(height: 10),
          _SpecRow(label: 'Nombre ficha', value: ficha.nombre),
          _SpecRow(label: 'Versión', value: ficha.version),
          _SpecRow(
            label: 'Estado',
            value: ficha.completado ? 'Completado' : 'Pendiente',
            valueColor: ficha.completado
                ? const Color(0xFF34C759)
                : const Color(0xFFFF9500),
          ),
          const SizedBox(height: 14),

          // Boton
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.open_in_new_rounded, size: 16),
              label: const Text('Ver ficha técnica completa'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.primary,
                side: const BorderSide(color: AppColors.primary),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(vertical: 12),
                textStyle: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 14,
          decoration: BoxDecoration(
              color: AppColors.primary, borderRadius: BorderRadius.circular(2)),
        ),
        const SizedBox(width: 8),
        Text(title,
            style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 13,
                fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class _SpecRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  const _SpecRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: const TextStyle(
                  color: AppColors.textSecondary, fontSize: 12)),
          Text(value,
              style: TextStyle(
                  color: valueColor ?? AppColors.textPrimary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final bool completado;
  const _StatusBadge({required this.completado});

  @override
  Widget build(BuildContext context) {
    final bg = completado ? const Color(0xFFE8F9EE) : const Color(0xFFFFF3E0);
    final fg = completado ? const Color(0xFF34C759) : const Color(0xFFFF9500);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(completado ? 'Completado' : 'Pendiente',
          style: TextStyle(
              color: fg, fontSize: 11, fontWeight: FontWeight.w700)),
    );
  }
}
