import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../shared/widgets/global_bottom_nav.dart';
import '../../../app_dependencies.dart';
import '../../../core/constants/app_colors.dart';
import '../../domain/entities/orden_entity.dart';
import '../providers/produccion_provider.dart';
import '../providers/orden_detail_provider.dart';
import '../state/produccion_state.dart';
import '../widgets/app_search_bar.dart';
import '../widgets/filter_chips_row.dart';
import '../widgets/orden_card.dart';
import '../widgets/toggle_tab_bar.dart';
import '../../../../../domain/terceros/features/presentation/widgets/terceros_embedded_list.dart';
import 'orden_detail_page.dart';
import 'calendario_page.dart';

class ProduccionPage extends StatefulWidget {
  const ProduccionPage({super.key});

  @override
  State<ProduccionPage> createState() => _ProduccionPageState();
}

class _ProduccionPageState extends State<ProduccionPage> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _goToDetail(BuildContext context, OrdenEntity orden) {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, animation, __) =>
            ChangeNotifierProvider<OrdenDetailProvider>(
          create: (_) => AppDependencies.createOrdenDetailProvider(),
          child: OrdenDetailPage(orden: orden),
        ),
        transitionsBuilder: (_, animation, __, child) => SlideTransition(
          position: animation.drive(
            Tween(begin: const Offset(1, 0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeOutCubic)),
          ),
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 320),
      ),
    );
  }

  void _goToCalendario(BuildContext context, List<OrdenEntity> ordenes) {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, animation, __) => CalendarioPage(ordenes: ordenes),
        transitionsBuilder: (_, animation, __, child) => SlideTransition(
          position: animation.drive(
            Tween(begin: const Offset(1, 0), end: Offset.zero)
                .chain(CurveTween(curve: Curves.easeOutCubic)),
          ),
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 320),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ProduccionProvider>(
      builder: (context, provider, _) {
        final state = provider.state;
        final isProduccion = state.activeTab == ProduccionTab.produccion;

        return Scaffold(
          backgroundColor: AppColors.background,
          bottomNavigationBar: const GlobalBottomNav(activeIndex: 3),
          body: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Header ──────────────────────────────────────────────
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text('Producción',
                                style: TextStyle(
                                    color: AppColors.textPrimary,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -0.4)),
                            Text('Gestión de órdenes',
                                style: TextStyle(
                                    color: AppColors.textSecondary, fontSize: 12)),
                          ],
                        ),
                      ),
                      // Botón calendario
                      if (isProduccion)
                        GestureDetector(
                          onTap: () => _goToCalendario(context, state.ordenes),
                          child: Container(
                            width: 38,
                            height: 38,
                            margin: const EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              color: AppColors.primaryLight,
                              borderRadius: BorderRadius.circular(11),
                            ),
                            child: const Icon(Icons.calendar_month_rounded,
                                color: AppColors.primary, size: 20),
                          ),
                        ),
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: AppColors.primarySoft,
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: AppColors.primary, width: 1.5),
                        ),
                        child: const Icon(Icons.person_outline_rounded,
                            size: 20, color: AppColors.primary),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // ── Toggle Producción / Terceros ─────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ToggleTabBar(
                    labels: const ['Producción', 'Terceros'],
                    activeIndex: isProduccion ? 0 : 1,
                    onChanged: (i) => provider.changeTab(
                        i == 0 ? ProduccionTab.produccion : ProduccionTab.terceros),
                  ),
                ),
                const SizedBox(height: 12),

                if (isProduccion) ...[
                  // ── Buscador ───────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: AppSearchBar(
                      controller: _searchCtrl,
                      onChanged: provider.setSearch,
                      hintText: 'Buscar orden o cliente...',
                    ),
                  ),
                  const SizedBox(height: 10),

                  // ── Filtros ────────────────────────────────────────────
                  FilterChipsRow(
                    filtroEstado: state.filtroEstado,
                    onEstadoChanged: provider.setFiltroEstado,
                  ),
                  const SizedBox(height: 10),
                ],

                // ── Lista ──────────────────────────────────────────────
                Expanded(
                  child: isProduccion
                      ? _OrdenList(
                          state: state,
                          onTap: (o) => _goToDetail(context, o),
                          onRetry: provider.loadOrdenes,
                        )
                      : const TercerosEmbeddedList(),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// ── Lista de órdenes ──────────────────────────────────────────────────────────

class _OrdenList extends StatelessWidget {
  final ProduccionState state;
  final ValueChanged<OrdenEntity> onTap;
  final VoidCallback onRetry;
  const _OrdenList({required this.state, required this.onTap, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    if (state.isLoading) {
      return const Center(
          child: CircularProgressIndicator(
              color: AppColors.primary, strokeWidth: 2.5));
    }

    if (state.hasError) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.error_outline_rounded,
              color: AppColors.primary, size: 48),
          const SizedBox(height: 12),
          Text(state.error!,
              style: const TextStyle(color: AppColors.textSecondary),
              textAlign: TextAlign.center),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: onRetry,
            style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10))),
            child: const Text('Reintentar'),
          ),
        ]),
      );
    }

    if (state.ordenes.isEmpty) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.inbox_rounded,
              size: 52, color: AppColors.textHint.withAlpha(120)),
          const SizedBox(height: 12),
          const Text('No hay órdenes',
              style: TextStyle(
                  color: AppColors.textSecondary, fontSize: 15)),
        ]),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      itemCount: state.ordenes.length,
      itemBuilder: (ctx, i) => OrdenCard(
        orden: state.ordenes[i],
        animIndex: i,
        onTap: () => onTap(state.ordenes[i]),
      ),
    );
  }
}
