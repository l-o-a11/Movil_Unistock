import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../domain/entities/ficha_costo_entity.dart';

/// Tarjeta de costos — usada internamente por la ficha técnica expandible
/// en orden_detail_page.dart. Se mantiene como widget reutilizable.
class FichaCostosCard extends StatelessWidget {
  final FichaCostoEntity ficha;
  const FichaCostosCard({super.key, required this.ficha});

  String _fmt(double v) {
    final s = v.toStringAsFixed(0);
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
          color: AppColors.primaryLight,
          borderRadius: BorderRadius.circular(12)),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Costo fijo por unidad',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 11)),
          const SizedBox(height: 4),
          Text('\$${_fmt(ficha.costoPorUnidad)}',
              style: const TextStyle(color: AppColors.primary,
                  fontSize: 17, fontWeight: FontWeight.w800)),
        ])),
        Container(width: 1, height: 40,
            color: AppColors.primary.withAlpha(40),
            margin: const EdgeInsets.symmetric(horizontal: 12)),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          const Text('Costo total del pedido',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 11),
              textAlign: TextAlign.end),
          const SizedBox(height: 4),
          Text('\$${_fmt(ficha.costoTotal)}',
              style: const TextStyle(color: AppColors.primary,
                  fontSize: 17, fontWeight: FontWeight.w800)),
        ])),
      ]),
    );
  }
}
