import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../domain/entities/orden_detail_entity.dart';

class EtapasCard extends StatelessWidget {
  final OrdenDetailEntity detail;
  const EtapasCard({super.key, required this.detail});

  static const _etapas = ['Diseño', 'Ficha técnica', 'Corte', 'Producción', 'Recepción'];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(8),
            blurRadius: 12, offset: const Offset(0, 3))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(width: 32, height: 32,
              decoration: BoxDecoration(color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.timeline_rounded,
                  color: AppColors.primary, size: 17)),
            const SizedBox(width: 10),
            const Text('Etapas de producción',
                style: TextStyle(color: AppColors.textPrimary,
                    fontSize: 14, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: _etapas.asMap().entries.map((e) {
              final i = e.key;
              final label = e.value;
              final done = i < detail.etapaActual;
              final active = i == detail.etapaActual;
              return _EtapaStep(label: label, done: done, active: active, isLast: i == _etapas.length - 1);
            }).toList(),
          ),
          if (detail.etapaActual < _etapas.length - 1) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(10)),
              child: Row(children: [
                const Icon(Icons.arrow_circle_right_rounded,
                    color: AppColors.primary, size: 16),
                const SizedBox(width: 8),
                Text('Siguiente: ${detail.siguienteEtapaLabel}',
                    style: const TextStyle(color: AppColors.primary,
                        fontSize: 12, fontWeight: FontWeight.w600)),
              ]),
            ),
          ],
        ],
      ),
    );
  }
}

class _EtapaStep extends StatelessWidget {
  final String label;
  final bool done;
  final bool active;
  final bool isLast;
  const _EtapaStep({required this.label, required this.done,
      required this.active, required this.isLast});

  @override
  Widget build(BuildContext context) {
    Color circleColor;
    Color textColor;
    Widget circleChild;

    if (done) {
      circleColor = AppColors.primary;
      textColor = AppColors.primary;
      circleChild = const Icon(Icons.check_rounded, color: Colors.white, size: 12);
    } else if (active) {
      circleColor = AppColors.primary;
      textColor = AppColors.primary;
      circleChild = Container(width: 6, height: 6,
          decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle));
    } else {
      circleColor = AppColors.chipBackground;
      textColor = AppColors.textHint;
      circleChild = const SizedBox.shrink();
    }

    return Expanded(
      child: Column(children: [
        Row(children: [
          if (label != 'Diseño')
            Expanded(child: Container(height: 1.5,
                color: done ? AppColors.primary : AppColors.cardBorder)),
          Container(width: 22, height: 22,
              decoration: BoxDecoration(color: circleColor, shape: BoxShape.circle),
              child: Center(child: circleChild)),
          if (!isLast)
            Expanded(child: Container(height: 1.5,
                color: done ? AppColors.primary : AppColors.cardBorder)),
        ]),
        const SizedBox(height: 6),
        Text(label,
            textAlign: TextAlign.center,
            style: TextStyle(color: textColor, fontSize: 9, fontWeight: FontWeight.w600),
            maxLines: 2, overflow: TextOverflow.ellipsis),
      ]),
    );
  }
}
