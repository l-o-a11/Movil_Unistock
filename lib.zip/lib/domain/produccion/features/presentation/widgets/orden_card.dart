import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../domain/entities/orden_entity.dart';

class OrdenCard extends StatelessWidget {
  final OrdenEntity orden;
  final VoidCallback onTap;
  final int animIndex;
  const OrdenCard({
    super.key,
    required this.orden,
    required this.onTap,
    this.animIndex = 0,
  });

  String _fmtDate(DateTime? d) {
    if (d == null) return '—';
    const m = ['', 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
        'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    return '${d.day} ${m[d.month]} ${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    final isTerceros = orden.tipo == OrdenTipo.terceros;
    final isActive = orden.isEnProduccion;

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 300 + animIndex * 60),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, (1 - v) * 16), child: child),
      ),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.cardBorder),
            boxShadow: [BoxShadow(color: Colors.black.withAlpha(6),
                blurRadius: 10, offset: const Offset(0, 3))],
          ),
          child: Row(
            children: [
              // Indicador de tipo
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: isTerceros ? AppColors.primaryLight : AppColors.chipBackground,
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  isTerceros
                      ? Icons.precision_manufacturing_rounded
                      : Icons.factory_rounded,
                  color: isTerceros ? AppColors.primary : AppColors.textSecondary,
                  size: 22,
                ),
              ),
              const SizedBox(width: 14),
              // Info principal
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('O.#${orden.numero}',
                            style: const TextStyle(color: AppColors.textPrimary,
                                fontSize: 15, fontWeight: FontWeight.w700)),
                        _EstadoBadge(estado: orden.estadoLabel, active: isActive),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(orden.cliente ?? '—',
                        style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 8),
                    Row(children: [
                      _Tag(label: 'Ref: ${orden.ref ?? "—"}'),
                      const SizedBox(width: 6),
                      _Tag(label: '${orden.unidades} uds'),
                      const SizedBox(width: 6),
                      _Tag(label: _fmtDate(orden.fechaEntrega),
                          icon: Icons.calendar_today_rounded),
                    ]),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.arrow_forward_ios_rounded,
                  size: 13, color: AppColors.iconInactive),
            ],
          ),
        ),
      ),
    );
  }
}

class _EstadoBadge extends StatelessWidget {
  final String estado;
  final bool active;
  const _EstadoBadge({required this.estado, required this.active});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: active ? AppColors.primaryLight : AppColors.chipBackground,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(estado,
          style: TextStyle(
              color: active ? AppColors.primary : AppColors.textSecondary,
              fontSize: 10, fontWeight: FontWeight.w600)),
    );
  }
}

class _Tag extends StatelessWidget {
  final String label;
  final IconData? icon;
  const _Tag({required this.label, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: AppColors.cardBorder)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[
          Icon(icon, size: 9, color: AppColors.textHint),
          const SizedBox(width: 3),
        ],
        Text(label,
            style: const TextStyle(
                color: AppColors.textSecondary, fontSize: 10, fontWeight: FontWeight.w500)),
      ]),
    );
  }
}
