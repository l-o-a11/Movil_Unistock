import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../../../shared/widgets/global_bottom_nav.dart';
import '../../../../../../shared/widgets/app_back_button.dart';
import '../../../../../../shared/widgets/profile_menu_button.dart';
import '../../../terceros_dependencies.dart';
import '../../domain/entities/tercero_entity.dart';
import '../providers/terceros_provider.dart';
import '../widgets/tercero_card.dart';

class TercerosPage extends StatelessWidget {
  const TercerosPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<TercerosProvider>(
      create: (_) => TercerosDependencies.createTercerosProvider(),
      child: const _TercerosBody(),
    );
  }
}

class _TercerosBody extends StatefulWidget {
  const _TercerosBody();

  @override
  State<_TercerosBody> createState() => _TercerosBodyState();
}

class _TercerosBodyState extends State<_TercerosBody> {
  final _ctrl = TextEditingController();
  List<TerceroEntity> _terceros = [];
  bool _loading = true;
  String? _error;

  static const _pink = Color(0xFFFF4FA3);
  static const _bg = Color(0xFFF5F5F7);
  static const _text = Color(0xFF1C1C1E);
  static const _grey = Color(0xFF8E8E93);

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _cargar() async {
    final provider = context.read<TercerosProvider>();
    await provider.loadTerceros();
    if (!mounted) return;
    final s = provider.state;
    setState(() {
      _terceros = s.terceros;
      _loading = s.isLoading;
      _error = s.error;
    });
  }

  List<TerceroEntity> get _filtrados {
    final q = _ctrl.text.toLowerCase();
    if (q.isEmpty) return _terceros;
    return _terceros.where((t) {
      return t.nombre.toLowerCase().contains(q) ||
          t.codigo.toLowerCase().contains(q) ||
          t.nit.toLowerCase().contains(q) ||
          t.contacto.toLowerCase().contains(q) ||
          t.telefono.toLowerCase().contains(q) ||
          t.direccion.toLowerCase().contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: const GlobalBottomNav(),
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Row(
                children: [
                  AppBackButton(),
                  const SizedBox(width: 14),
                  const Text(
                    'Terceros',
                    style: TextStyle(
                      color: _text,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.4,
                    ),
                  ),
                  const Spacer(),
                  ProfileMenuButton(size: 42, iconSize: 20),
                ],
              ),
            ),

            // ── Buscador (mismo estilo que ProveedoresPage) ─────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                height: 46,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFEEEEEE)),
                ),
                child: Row(
                  children: [
                    const SizedBox(width: 12),
                    const Icon(
                      Icons.search_rounded,
                      color: Color(0xFFAEAEB2),
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _ctrl,
                        onChanged: (v) => setState(() {}),
                        style: const TextStyle(
                          color: Color(0xFF8E8E93),
                          fontSize: 15,
                        ),
                        decoration: const InputDecoration(
                          hintText: 'Buscar terceros...',
                          hintStyle: TextStyle(
                            color: Color(0xFFAEAEB2),
                            fontSize: 15,
                          ),
                          border: InputBorder.none,
                          isDense: true,
                        ),
                      ),
                    ),
                    if (_ctrl.text.isNotEmpty)
                      GestureDetector(
                        onTap: () {
                          _ctrl.clear();
                          setState(() {});
                        },
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Icon(
                            Icons.close_rounded,
                            color: Color(0xFFAEAEB2),
                            size: 18,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: _loading
                  ? const Center(
                      child: CircularProgressIndicator(color: _pink),
                    )
                  : _error != null
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.error_outline_rounded,
                            color: Colors.red,
                            size: 40,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _error!,
                            style: const TextStyle(color: Colors.red),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      color: _pink,
                      onRefresh: _cargar,
                      child: _filtrados.isEmpty
                          ? const Center(
                              child: Text(
                                'No se encontraron terceros.',
                                style: TextStyle(color: _grey),
                              ),
                            )
                          : ListView.separated(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              itemCount: _filtrados.length,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 12),
                              itemBuilder: (context, index) {
                                return TerceroCard(
                                  tercero: _filtrados[index],
                                  animIndex: index,
                                );
                              },
                            ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}