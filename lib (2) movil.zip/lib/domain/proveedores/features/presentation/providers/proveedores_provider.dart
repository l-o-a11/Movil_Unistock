import 'package:flutter/material.dart';
import '../../domain/entities/proveedor_entity.dart';
import '../../data/services/proveedores_api_service.dart';

const int kProveedoresPageSize = 5;

/// Proveedor de estado para la lista de proveedores.
/// 
/// Gestiona:
/// - Carga de proveedores desde [ProveedoresApiService]
/// - Búsqueda de texto
/// - Estados de carga y error
/// 
/// Propiedades públicas:
/// - [items]: lista de proveedores
/// - [isLoading]: indica carga en progreso
/// - [error]: mensaje de error (null si no hay error)
class ProveedoresProvider extends ChangeNotifier {
  final ProveedoresApiService _apiService;
  List<ProveedorEntity> items = [];
  bool isLoading = true;
  String? error;
  String _q = '';
  int _visibleCount = kProveedoresPageSize;

  List<ProveedorEntity> get visibleItems =>
      items.take(_visibleCount).toList();
  bool get hasMore => _visibleCount < items.length;

  List<ProveedorEntity> get proveedoresFiltrados {
    final q = _q.trim().toLowerCase();
    if (q.isEmpty) return items;
    return items.where((p) {
      return p.nombre.toLowerCase().contains(q) ||
          p.nit.toLowerCase().contains(q) ||
          p.contacto.toLowerCase().contains(q) ||
          p.telefono.toLowerCase().contains(q) ||
          p.direccion.toLowerCase().contains(q) ||
          p.correo.toLowerCase().contains(q) ||
          p.sitioWeb.toLowerCase().contains(q);
    }).toList();
  }

  ProveedoresProvider({ProveedoresApiService? apiService})
      : _apiService = apiService ?? ProveedoresApiService() {
    load();
  }

  /// Carga la lista de proveedores desde el servicio API.
  /// 
  /// Parámetro:
  /// - [q]: Búsqueda opcional (actualiza la consulta si se proporciona)
  Future<void> load({String? q}) async {
    _q = q ?? _q;
    _visibleCount = kProveedoresPageSize;
    notifyListeners();
    try {
      items = await _apiService.getAll(query: _q.isEmpty ? null : _q);
    } catch (e) { error = 'Error al cargar: $e'; }
    isLoading = false; notifyListeners();
  }

  /// Realiza búsqueda de proveedores y recarga la lista.
  /// 
  /// Parámetro:
  /// - [q]: Término de búsqueda
  void search(String q) => load(q: q);

  /// Expande la lista en bloques de cinco registros.
  void showMore() {
    if (!hasMore) return;
    _visibleCount += kProveedoresPageSize;
    notifyListeners();
  }
}
