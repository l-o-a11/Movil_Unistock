import 'package:flutter/material.dart';

import '../../domain/entities/orden_detail_entity.dart';
import '../../domain/entities/orden_referencia_entity.dart';
import '../../domain/entities/historial_entry_entity.dart';
import '../../domain/entities/ficha_costo_entity.dart';

/// Modelo de datos del detalle de una orden. Extiende [OrdenDetailEntity]
/// y sabe cómo construirse desde JSON.
class OrdenDetailModel extends OrdenDetailEntity {
  const OrdenDetailModel({
    required super.id,
    required super.numero,
    required super.unidades,
    required super.estado,
    required super.tipo,
    super.cliente,
    super.fechaEntrega,
    super.refCorte,
    super.ref,
    super.fechaEstado,
    required super.progreso,
    required super.etapaActual,
    required super.referencias,
    required super.historial,
    super.fichaCosto,
  });

  factory OrdenDetailModel.fromJson(Map<String, dynamic> json) {
    // Helper to safely read a string from multiple possible keys
    String? readString(dynamic v) => v == null ? null : v.toString();

    final detalles = (json['detalles'] as List<dynamic>?) ?? [];

    // refCorte: prefer explicit field, otherwise first detalle.id_producto
    String? refCorte =
        readString(json['refCorte']) ??
        (detalles.isNotEmpty ? readString(detalles[0]['id_producto']) : null) ??
        (detalles.isNotEmpty ? readString(detalles[0]['idProduct']) : null);

    // ref: puede venir en 'ref', 'referencia' (objeto o string) o 'producto'
    String? ref;
    if (json['ref'] != null)
      ref = readString(json['ref']);
    else if (json['referencia'] != null) {
      final refObj = json['referencia'];
      if (refObj is Map) {
        ref =
            readString(refObj['nombre']) ??
            readString(refObj['ref']) ??
            readString(refObj['codigo']);
      } else if (refObj is String)
        ref = refObj;
    }
    ref ??= readString(json['producto']);

    // fechaEstado: prefer explicit campo, si no usar última entrada del historial o updatedAt/updated_at
    DateTime? fechaEstado;
    if (json['fechaEstado'] != null)
      fechaEstado = DateTime.tryParse(json['fechaEstado'].toString());
    else {
      final historial = (json['historial'] as List<dynamic>?) ?? [];
      if (historial.isNotEmpty) {
        final last = historial.last;
        fechaEstado = DateTime.tryParse(readString(last['fecha']) ?? '');
      }
      fechaEstado ??= DateTime.tryParse(
        readString(json['updatedAt']) ?? readString(json['updated_at']) ?? '',
      );
    }

    // referencias
    final referencias =
        (json['referencias'] as List<dynamic>?)
            ?.map(
              (r) => OrdenReferenciaEntity(
                codigo: (r['codigo'] ?? r['ref'] ?? r['referencia'] ?? '')
                    .toString(),
                cantidad: ((r['cantidad'] ?? r['qty'] ?? 0) as num).toInt(),
                color: _parseColor(
                  (r['colorHex'] ?? r['colorHexCode'] ?? '#000000').toString(),
                ),
                colorName: (r['colorName'] ?? r['color'] ?? '').toString(),
              ),
            )
            .toList() ??
        [];

    // historial
    final historial =
        (json['historial'] as List<dynamic>?)
            ?.map(
              (h) => HistorialEntryEntity(
                etapa: (h['etapa'] ?? h['estado'] ?? '').toString(),
                fecha:
                    DateTime.tryParse(
                      (h['fecha'] ?? h['date'] ?? '').toString(),
                    ) ??
                    DateTime.now(),
                responsable: (h['responsable'] ?? h['user'] ?? '').toString(),
              ),
            )
            .toList() ??
        [];

    // ficha técnica — aceptar varios nombres de campo
    dynamic fichaRaw =
        json['fichaCosto'] ??
        json['ficha_tecnica'] ??
        json['fichaTecnica'] ??
        json['ficha'];
    FichaCostoEntity? ficha;
    if (fichaRaw is Map) {
      final nombre =
          readString(fichaRaw['nombre']) ??
          readString(fichaRaw['name']) ??
          'Ficha técnica';
      final version =
          readString(fichaRaw['version']) ??
          readString(fichaRaw['versión']) ??
          readString(fichaRaw['versionName']) ??
          '';
      final costoPorUnidadRaw =
          fichaRaw['costoPorUnidad'] ?? fichaRaw['costPerUnit'] ?? 0;
      final costoTotalRaw =
          fichaRaw['costoTotal'] ?? fichaRaw['totalCost'] ?? 0;
      final costoPorUnidad = costoPorUnidadRaw is num
          ? costoPorUnidadRaw.toDouble()
          : double.tryParse(costoPorUnidadRaw.toString()) ?? 0.0;
      final costoTotal = costoTotalRaw is num
          ? costoTotalRaw.toDouble()
          : double.tryParse(costoTotalRaw.toString()) ?? 0.0;
      final completado =
          fichaRaw['completado'] ?? fichaRaw['completed'] ?? false;
      ficha = FichaCostoEntity(
        nombre: nombre,
        version: version ?? '',
        costoPorUnidad: costoPorUnidad,
        costoTotal: costoTotal,
        completado: completado as bool,
      );
    }

    // Parse numeric/simple fields safely
    final numero = (json['numero_orden'] ?? json['numero'] ?? 0);
    final unidadesRaw =
        json['unidades'] ??
        detalles.fold<int>(
          0,
          (s, d) => s + ((d['cantidad'] ?? 0) as num).toInt(),
        );
    final unidades = unidadesRaw is num
        ? unidadesRaw.toInt()
        : int.tryParse(unidadesRaw.toString()) ?? 0;
    final progresoRaw = json['progreso'] ?? 0.0;
    final progreso = progresoRaw is num
        ? progresoRaw.toDouble()
        : double.tryParse(progresoRaw.toString()) ?? 0.0;
    // Normalizar progreso: aceptar tanto 0.0-1.0 como 0-100
    double normalizedProgreso = progreso;
    if (normalizedProgreso > 1.0 && normalizedProgreso <= 100.0) {
      normalizedProgreso = normalizedProgreso / 100.0;
    } else if (normalizedProgreso > 100.0) {
      normalizedProgreso = 1.0;
    } else if (normalizedProgreso < 0.0) {
      normalizedProgreso = 0.0;
    }
    final etapaRaw = json['etapaActual'] ?? json['etapa'] ?? 0;
    final etapaActual = etapaRaw is num
        ? (etapaRaw as num).toInt()
        : int.tryParse(etapaRaw.toString()) ?? 0;

    return OrdenDetailModel(
      id: (json['_id'] ?? json['id'] ?? '').toString(),
      numero: numero is num
          ? (numero as num).toInt()
          : int.tryParse(numero.toString()) ?? 0,
      unidades: unidades,
      estado: (json['estado'] ?? '').toString(),
      tipo: (json['tipo'] ?? 'produccion').toString().toLowerCase(),
      cliente: readString(json['cliente'] ?? json['client']),
      fechaEntrega: json['fechaEntrega'] != null
          ? DateTime.tryParse(json['fechaEntrega'].toString())
          : null,
      refCorte: refCorte,
      ref: ref,
      fechaEstado: fechaEstado,
      progreso: normalizedProgreso,
      // usar progreso normalizado
      etapaActual: etapaActual,
      // override progreso with normalized value
      // (constructor uses named args; pass normalizedProgreso)
      referencias: referencias,
      historial: historial,
      fichaCosto: ficha,
    );
  }

  static Color _parseColor(String hex) {
    final h = hex.replaceFirst('#', '');
    return Color(int.parse('FF$h', radix: 16));
  }
}
