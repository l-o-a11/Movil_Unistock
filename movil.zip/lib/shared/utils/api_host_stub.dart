String getApiHost() => 'localhost';
