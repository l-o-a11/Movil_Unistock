import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../shared/widgets/global_bottom_nav.dart';
import '../../data/dashboard_data_source.dart';
import '../providers/dashboard_provider.dart';

const Color _pink = Color(0xFFFF4FA3);
const Color _bg = Color(0xFFF5F5F7);
const Color _text = Color(0xFF1C1C1E);

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => DashboardProvider(dataSource: DashboardDataSource()),
      child: const _DashboardView(),
    );
  }
}

class _DashboardView extends StatelessWidget {
  const _DashboardView();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      bottomNavigationBar: const GlobalBottomNav(activeIndex: 0),
      body: SafeArea(
        child: Consumer<DashboardProvider>(
          builder: (context, provider, __) {
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _CircleIcon(icon: Icons.show_chart_rounded),
                      _CircleIcon(icon: Icons.person_outline_rounded),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                _TileSection(),
                const SizedBox(height: 16),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      children: [
                        _StatusCard(provider: provider),
                        const SizedBox(height: 20),
                        _ChartCard(provider: provider),
                        const SizedBox(height: 90),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  child: SizedBox(
                    height: 54,
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _pink,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      onPressed: () {
                        Navigator.pushReplacementNamed(context, '/menu');
                      },
                      child: const Text(
                        'Acceder',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _CircleIcon extends StatelessWidget {
  final IconData icon;
  const _CircleIcon({required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: const [
          BoxShadow(color: Color(0x12000000), blurRadius: 18, offset: Offset(0, 8)),
        ],
      ),
      child: Icon(icon, color: _pink, size: 22),
    );
  }
}

class _TileSection extends StatelessWidget {
  const _TileSection();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _ActionTile(icon: Icons.trending_up_rounded, title: 'Producción'),
          _ActionTile(icon: Icons.insights_rounded, title: 'Resumen'),
          _ActionTile(icon: Icons.inventory_2_outlined, title: 'Insumos'),
          _ActionTile(icon: Icons.article_outlined, title: 'Reportes'),
        ],
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;

  const _ActionTile({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(color: Color(0x0F000000), blurRadius: 20, offset: Offset(0, 8)),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _pink.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: _pink, size: 20),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12, color: _text),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final DashboardProvider provider;

  const _StatusCard({required this.provider});

  @override
  Widget build(BuildContext context) {
    if (provider.isLoading) {
      return const SizedBox(height: 180, child: Center(child: CircularProgressIndicator()));
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(color: Color(0x16000000), blurRadius: 28, offset: Offset(0, 10)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Estado general de los procesos de producción',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: _text),
          ),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: provider.metrics
                .map((metric) => _MetricTile(metric: metric))
                .toList(),
          ),
        ],
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  final dynamic metric;

  const _MetricTile({required this.metric});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: metric.color.withOpacity(0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(metric.icon, color: metric.color, size: 20),
          ),
          const SizedBox(height: 12),
          Text(
            metric.title,
            style: const TextStyle(fontSize: 12, color: _text),
          ),
          const SizedBox(height: 4),
          Text(
            metric.subtitle,
            style: const TextStyle(fontSize: 11, color: Color(0xFF8E8E93)),
          ),
        ],
      ),
    );
  }
}

class _ChartCard extends StatelessWidget {
  final DashboardProvider provider;

  const _ChartCard({required this.provider});

  @override
  Widget build(BuildContext context) {
    final maxValue = provider.chartPoints.isEmpty
        ? 1
        : provider.chartPoints.map((point) => point.value).reduce((a, b) => a > b ? a : b);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(color: Color(0x16000000), blurRadius: 28, offset: Offset(0, 10)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Estado general de los procesos de producción',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: _text),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 220,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: provider.chartPoints.map((point) {
                final height = (point.value / maxValue) * 160 + 24;
                final isPink = point.label == 'En espera';
                return Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        height: height,
                        width: 18,
                        decoration: BoxDecoration(
                          color: isPink ? _pink : const Color(0xFF00C853),
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Flexible(
                        child: Text(
                          point.label,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 10, color: Color(0xFF8E8E93)),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
