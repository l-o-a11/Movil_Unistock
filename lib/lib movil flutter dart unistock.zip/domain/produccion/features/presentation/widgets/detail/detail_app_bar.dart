import 'package:flutter/material.dart';
import '../../../../../../shared/widgets/app_back_button.dart';
import '../../../../../../shared/widgets/profile_menu_button.dart';
import '../../../../core/constants/app_colors.dart';

/// AppBar personalizada para la pantalla de detalle de orden.
class DetailAppBar extends StatelessWidget implements PreferredSizeWidget {
  final int ordenNumero;

  const DetailAppBar({super.key, required this.ordenNumero});

  @override
  Size get preferredSize => const Size.fromHeight(60);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.background,
      elevation: 0,
      scrolledUnderElevation: 0,
      leadingWidth: 64,
      leading: Padding(
        padding: const EdgeInsets.only(left: 16),
        child: Center(child: AppBackButton()),
      ),
      title: Text(
        'Orden de Producción #$ordenNumero',
        style: const TextStyle(
          color: AppColors.textPrimary,
          fontSize: 16,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.3,
        ),
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: ProfileMenuButton(
            size: 42,
            iconSize: 20,
          ),
        ),
      ],
    );
  }
}
 
