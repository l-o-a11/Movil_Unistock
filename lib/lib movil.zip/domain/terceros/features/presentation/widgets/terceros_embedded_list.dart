import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../produccion/core/constants/app_colors.dart';
import '../providers/terceros_provider.dart';
import 'tercero_card.dart';

class TercerosEmbeddedList extends StatelessWidget {
  const TercerosEmbeddedList({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<TercerosProvider>(
      builder: (context, provider, _) {
        final state = provider.state;

        if (state.isLoading) {
          return const Center(
            child: CircularProgressIndicator(
              color: AppColors.primary,
              strokeWidth: 2.5,
            ),
          );
        }

        if (state.error != null) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.error_outline,
                  color: AppColors.primary,
                  size: 48,
                ),
                const SizedBox(height: 12),
                Text(
                  state.error!,
                  style: const TextStyle(color: AppColors.textSecondary),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: provider.loadTerceros,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: const Text('Reintentar'),
                ),
              ],
            ),
          );
        }

        final filtered = state.tercerosFiltrados;
        if (filtered.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  state.searchActive
                      ? Icons.search_off_rounded
                      : Icons.people_outline,
                  size: 52,
                  color: AppColors.textHint.withAlpha(120),
                ),
                const SizedBox(height: 12),
                Text(
                  state.searchActive
                      ? 'No se encontraron resultados para "${state.searchQuery}"'
                      : 'No hay terceros disponibles',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
          );
        }

        final visibles = state.tercerosVisibles;
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          itemCount: visibles.length + (state.hasMore ? 1 : 0),
          itemBuilder: (context, index) {
            if (index == visibles.length) {
              return Padding(
                padding: const EdgeInsets.only(top: 4, bottom: 12),
                child: Center(
                  child: OutlinedButton(
                    onPressed: provider.showMore,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: BorderSide(color: AppColors.primary.withValues(alpha: 0.4)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text('Ver más'),
                  ),
                ),
              );
            }
            return TerceroCard(tercero: visibles[index], animIndex: index);
          },
        );
      },
    );
  }
}
